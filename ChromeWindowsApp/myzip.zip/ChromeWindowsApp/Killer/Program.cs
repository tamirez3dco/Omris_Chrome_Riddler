﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SuspenderLib;

namespace Killer
{
    class Program
    {
        static void Main(string[] args)
        {
            SuspenderLib.Processer.KillRiddleApp();
        }
    }
}
