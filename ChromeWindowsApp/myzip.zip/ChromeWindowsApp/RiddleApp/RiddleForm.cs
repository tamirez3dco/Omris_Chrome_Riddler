﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using SuspenderLib;
using System.Diagnostics;
using System.Threading;
using System.IO;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Media;

using HAVARA = System.Collections.Generic.List<int>;

namespace RiddleApp
{

    public partial class RiddleForm : Form
    {
        public System.Media.SoundPlayer buzzer_player;
        public System.Media.SoundPlayer gling_player;
        public List<System.Media.SoundPlayer> havara_players;
        public System.Media.SoundPlayer word_player;
        public System.Media.SoundPlayer kolkavod_player;
        public RiddleForm()
        {
            InitializeComponent();
            extraInitializations();
        }


        public static String mainResourcesPath = @"C:\Users\tamirlev\Documents\Visual Studio 2010\Projects\ChromeWindowsApp\SoundsImagesVideos\";

        public HebrewWord chosenWord;
        public void extraInitializations()
        {
            this.Location = new Point(100, 100);
            buzzer_player = new System.Media.SoundPlayer(mainResourcesPath+"buzzer_x.wav");
            buzzer_player.Load();
            gling_player = new System.Media.SoundPlayer(mainResourcesPath + "GLING.wav");
            gling_player.Load();
            kolkavod_player = new System.Media.SoundPlayer(mainResourcesPath + "kol_hakavod_lemushmush.wav");
            kolkavod_player.Load();

        }

        public virtual void setup_riddle() 
        {
            riddleImage.Image = new Bitmap(mainResourcesPath + @"words_sounds\" + chosenWord.filename + ".jpg");
        }







        public void play_kolkavod_and_set_close_timers()
        {
            kolkavod_player.Play();
            kol_kavod_Timer.Start();
        }





        private void kol_kavod_Timer_Tick(object sender, EventArgs e)
        {
            this.Close();
        }

        int code_counter = 0;
        private void RiddleForm_KeyDown(object sender, KeyEventArgs e)
        {
            Debug.WriteLine("RiddleForm_KeyDown()");
            e.Handled = true;
            if ((e.KeyCode == Keys.F11) && (code_counter == 0))
            {
                code_counter++;
                return;
            }
            if ((e.KeyCode == Keys.F9) && (code_counter == 1))
            {
                code_counter++;
                return;
            }
            if ((e.KeyCode == Keys.F5) && (code_counter == 2))
            {
                Program.quit = true;
                this.Close();
            }

        }


    }
}
