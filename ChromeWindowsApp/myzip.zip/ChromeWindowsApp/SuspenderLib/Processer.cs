﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Windows.Automation;
using System.Windows.Forms;

namespace SuspenderLib
{
    public class Processer
    {
        public static String mainResourcesPath = @"C:\Users\tamirlev\Documents\Visual Studio 2010\Projects\ChromeWindowsApp\SoundsImagesVideos\";
        public static String mainPsSuspendPath = @"C:\Users\tamirlev\Documents\Visual Studio 2010\Projects\ChromeWindowsApp\Pssuspend\";

        public static string GetChromeUrl(Process process)
        {
            String res = null;

            if (process == null)
                throw new ArgumentNullException("process");

            if (process.MainWindowHandle == IntPtr.Zero)
                return null;

            AutomationElement element = AutomationElement.FromHandle(process.MainWindowHandle);
            if (element == null)
                return null;

            try
            {

                AutomationElement edit = element.FindFirst(TreeScope.Children, new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Edit));
                res = ((ValuePattern)edit.GetCurrentPattern(ValuePattern.Pattern)).Current.Value as string;
            }
            catch (Exception e)
            {
                Debug.WriteLine("Exception on pid=" + process.Id + "  e=" + e.Message);
                return null;
            }

            return res;

        }

        public static bool GetChromesPlayingYouTube()
        {
            Process[] chromeProceses = Process.GetProcessesByName("chrome");
            foreach (Process p in chromeProceses)
            {
                String url = SuspenderLib.Processer.GetChromeUrl(p);
                Debug.WriteLine("url=" + url);
            }


            return true;
        }

        public static void SuspendChrome(bool resume=false)
        {
            ProcessStartInfo psi = new ProcessStartInfo();
            psi.WorkingDirectory = mainPsSuspendPath;
            psi.FileName = "pssuspend.exe";
            //psi.UseShellExecute = false;
            if (resume) psi.Arguments = "-r Chrome.exe";
            else psi.Arguments = "Chrome.exe";
            Process.Start(psi);
        }

        public static void KillRiddleApp()
        {
            Debug.WriteLine("KillRiddleApp()");
            ProcessStartInfo psi = new ProcessStartInfo();
            psi.WorkingDirectory = mainPsSuspendPath;
            psi.FileName = "pskill.exe";
            psi.Arguments = "RiddleApp.exe";
            Process.Start(psi);
        }

    }
}
